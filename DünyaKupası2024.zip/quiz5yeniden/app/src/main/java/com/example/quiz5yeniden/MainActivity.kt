package com.example.quiz5yeniden

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var rv: RecyclerView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initUI()
        loadData()
    }

    private fun loadData() {
        val stadiums = StadiumRepository().getStadiums()

        rv.setHasFixedSize(true)
        rv.layoutManager = LinearLayoutManager(applicationContext)
        rv.layoutManager = GridLayoutManager(applicationContext,2)
        val adapter = StadiumAdapter(this, stadiums)
        rv.adapter = adapter

    }

    private fun initUI() {

        rv = findViewById(R.id.rv)

    }
}