package com.example.quiz5yeniden

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class StadiumAdapter(val context: Context, val dataset: ArrayList<StadiumModel>)
    : RecyclerView.Adapter<StadiumAdapter.ViewHolder> () {
    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val resim : ImageView = itemView.findViewById(R.id.ivStadiumImage)
        val kapasite: TextView = itemView.findViewById(R.id.tvCapacity)
        val konum: TextView = itemView.findViewById(R.id.tvLocation)
        val baslik: TextView= itemView.findViewById(R.id.title)
        val likebutton= itemView.findViewById<ImageView>(R.id.ivLikeButton)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.stadyum_card, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return dataset.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val stadium = dataset[position]
        with(holder) {
            baslik.text = stadium.title
            konum.text=stadium.location
            kapasite.text=stadium.capacity
            likebutton.setOnClickListener {
                Toast.makeText(it.context, "You liked ${stadium.title}", Toast.LENGTH_SHORT).show()
            }
            Glide.with(holder.itemView.context)
                .load(stadium.image)
                .into(resim)
        }
    }

        }
