package com.example.quiz5yeniden

data class StadiumModel(
    val id: Int,
    val title: String,
    val image: Int,
    val location: String,
    val capacity: String
)
