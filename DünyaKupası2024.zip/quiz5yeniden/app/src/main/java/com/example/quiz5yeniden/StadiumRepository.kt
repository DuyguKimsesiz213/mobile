package com.example.quiz5yeniden

class StadiumRepository { fun getStadiums(): ArrayList<StadiumModel> {
    val Stadiums = ArrayList<StadiumModel>()

    Stadiums.add(StadiumModel(1,"Luseyl Stadyumu", R.drawable.luseyl,"Luseyl" ,"80000"))
    Stadiums.add(StadiumModel(2,"El-Beyt Stadyumu", R.drawable.elbeyt, "Havr","60000"))
    Stadiums.add(StadiumModel(3,"Stadyum 974", R.drawable.stadyum974,"Doha" ,"40000"))
    Stadiums.add(StadiumModel(4,"Es-Sümame Stadyumu", R.drawable.essuname,"Doha" ,"40000"))
    Stadiums.add(StadiumModel(5,"Eğitim Şehri Stadyumu", R.drawable.egitimsehri,"Er-Reyyan" ,"80000"))

    return Stadiums
}
}